var searchData=
[
  ['getcolour_0',['GetColour',['../class_shape.html#a88554b555eae9ec283a624ef0e8d8305',1,'Shape']]],
  ['getname_1',['GetName',['../class_shape.html#a7af8e23f8cce0f52e526b45b45818917',1,'Shape']]],
  ['getradius_2',['GetRadius',['../class_circle.html#a1d5a7069b34da46ae0c3a1160ef5ff29',1,'Circle']]],
  ['getsidelength_3',['GetSideLength',['../class_square.html#accda78726f7986e834e13838bdc68435',1,'Square']]]
];
