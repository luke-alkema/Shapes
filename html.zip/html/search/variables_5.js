var searchData=
[
  ['name',['name',['../class_dog.html#a95e00e00632f05db88345f7e07f65010',1,'Dog']]],
  ['neutered',['neutered',['../class_dog.html#a22198d89fe36068f47a8138a8e715a43',1,'Dog']]]
];
