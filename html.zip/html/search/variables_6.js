var searchData=
[
  ['shedder',['shedder',['../class_dog.html#ac96788d7cc54f6694e9eda88eb8f0a8f',1,'Dog']]],
  ['size',['size',['../class_dog.html#ac8c8bfe95f5a43754424b06c4958ecf6',1,'Dog']]]
];
