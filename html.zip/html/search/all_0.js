var searchData=
[
  ['_3a_0',['Current version of the Dog Project :',['../index.html#version',1,'']]]
];
