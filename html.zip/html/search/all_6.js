var searchData=
[
  ['name_0',['name',['../class_shape.html#afef5e9426226fd7af49fe48ec16b97f3',1,'Shape']]]
];
