var searchData=
[
  ['setradius_0',['SetRadius',['../class_circle.html#a09f07ad86e16507b6db8bee35aa67962',1,'Circle']]],
  ['shape_1',['Shape',['../class_shape.html#ad735b927c63c190803e2b9af27e4c25d',1,'Shape::Shape(string name, string colour)'],['../class_shape.html#a2c81e227edd2803a084c65c75e4ffd5b',1,'Shape::Shape(void)']]],
  ['show_2',['Show',['../class_circle.html#a9ade44170d48efc91d3c35e8be4e4b5a',1,'Circle::Show()'],['../class_square.html#a2a7e3a73cfbe9045d8a27dd8f738fda9',1,'Square::Show(void)']]],
  ['square_3',['Square',['../class_square.html#a3dc7ff9aefc2725172b5d3153973d243',1,'Square::Square()'],['../class_square.html#ab99fbb5ea8ba88349120e2f4f9a18b8a',1,'Square::Square(string newColour, double newSideLength)']]]
];
