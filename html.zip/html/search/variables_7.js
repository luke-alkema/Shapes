var searchData=
[
  ['weight',['weight',['../class_dog.html#a565b563cf859d8d0a2bdfe7101ebd4e6',1,'Dog']]]
];
