var searchData=
[
  ['colour_0',['colour',['../class_shape.html#a525db72bc0e96e0daa2c1bd0ce8cb076',1,'Shape']]]
];
